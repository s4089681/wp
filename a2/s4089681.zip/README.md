# Introduction
This folder contains the source code to RMIT COSC2446 Assesment 1

## Overview
> Create a website for a fictitious pet adoption agency - Pets victoria that will display pets available for adoption.  The assignment is an individual task that will require an individual submission

### Jupiter Core Teaching Deployment
> https://titan.csit.rmit.edu.au/~s4089681/wp/

The assesment is deployed on RMITs Titan core teaching server, behind appropriate .htaccess restrictions 
